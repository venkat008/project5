# RED Widget Boilerplate

A template for a WordPress widget plugin for RED Academy students.

Lightly forked from the [WordPress Widget Boilerplate](https://github.com/tommcfarlin/WordPress-Widget-Boilerplate) by [@tommcfarlin](https://github.com/tommcfarlin).
