# RED Functionality Plugin

A template for a WordPress functionality plugin for RED Academy students.
